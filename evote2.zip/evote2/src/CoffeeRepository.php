<?php


namespace Tudublin;

use Mattsmithdev\PdoCrudRepo\DatabaseTableRepository;

class CoffeeRepository extends DatabaseTableRepository
{

}